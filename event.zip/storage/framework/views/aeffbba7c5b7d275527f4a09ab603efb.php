
<div class="wrapper">
    <style>
        ul.list li a {
            color: #222;
        }

        .categories .list .panel-group .panel-title a {
            background: #283C82;
            color: #fff;
        }

        .categories .list .panel-group .panel-content {
            background: #283C82;
            padding: 10px 0 0 20px
        }

        .categories .list .panel-group .panel-title a::after {
            padding: 0;
            color: #fff;
            font-size: 12px;
        }

        .categories .list .panel-group .panel-title a {
            padding: 0 0 0 20px
        }

        .categories .list .panel-group .panel-title a.active {
            background: #283C82 !important;
            border-bottom: none !important
        }

        .categories .list .panel-group .panel-title a.active::after {
            background: #283C82 !important;
        }
    </style>
    <div class="main-content">
        <section id="home" class="divider">

            <div class="container-fluid p-0">

                <div class="event-detail-image">
                    <img src="/backend_assets/images/banners/banner.jpeg" alt=""
                        data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg"
                        data-bgparallax="6" data-no-retina="">
                </div>
                <!-- end .rev_slider_wrapper -->
                
                <!-- Slider Revolution Ends -->
            </div>
        </section>
        <!-- Section: About -->
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-md-8  wow fadeInUp" data-wow-duration="1.5s" data-wow-offset="10"
                        style="visibility: visible; animation-duration: 1.5s;">
                        
                        <h2 class="title text-gray font-40  mt-0 mb-20"><?php echo e($events->name); ?></h2>
                        <div class="entry-meta mb-20">
                            <h5>
                                <span><i class="fa fa-user text-theme-colored">Organized By:</i>
                                    <?php echo e($events->organizer_name); ?></span> <br>
                                <span><i class="fa fa-user text-theme-colored">Location:</i>
                                    <?php echo e($events->location); ?></span> <br>
                                <span><i class="fa fa-user text-theme-colored">Start Date:</i>
                                    <?php echo e($events->start_date); ?></span><br>
                                <span><i class="fa fa-user text-theme-colored">End Date:</i>
                                    <?php echo e($events->end_date); ?></span><br>
                                <span><i class="fa fa-user text-theme-colored">Time:</i>
                                    <?php echo e(\Carbon\Carbon::parse($events->event_time)->format('h:i a')); ?>

                                </span>
                            </h5>

                            
                        </div>
                        
                        <!--   <a class="btn btn-colored btn-theme-colored btn-lg text-uppercase smooth-scroll font-13 mt-30" href="#schedule">See Event Schedule</a>
                <a class="btn btn-dark-light btn-lg text-uppercase smooth-scroll font-13 mt-30" href="#tickets">Register Now</a> -->
                    </div>
                    <div class="col-md-4">
                        <div class="widget">
                            <!--   <h5 class="widget-title line-bottom">Links</h5> -->
                            <div class="categories">
                                <ul class="list "
                                    style="
                                          background: #f2f2f2;
                                          padding: 20px;">
                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022">Overview</a>
                                    </li>

                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/downloads/certificates/event/6">Download
                                            Certificate</a>
                                    </li>

                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/about">Significance
                                            of the Conference</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/message-from-honorable-pm-5">Message
                                            from Rt. Honorable PM</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/management-committee">Management
                                            Committee</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/scientific-committee">Scientific
                                            Committee</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/general-symposia">General
                                            Symposia</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/abstract-submission">Abstract
                                            Submission</a></li>


                                    <div id="accordion122" class="panel-group accordion">
                                        <div class="panel">
                                            <div class="panel-title">
                                                <a data-parent="#accordion122" data-toggle="collapse"
                                                    href="#accordion1122" class="" aria-expanded="true"> <span
                                                        class="open-sub"></span> Speakers</a>
                                            </div>
                                            <div id="accordion1122" class="panel-collapse collapse" role="tablist"
                                                aria-expanded="true">
                                                <div class="panel-content">
                                                    <li><i
                                                            class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/keynote-speakers">Keynote
                                                            Speakers</a></li>
                                                    <li><i
                                                            class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/invited-international-speakers">Invited
                                                            International Speakers</a></li>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/program">Program</a>
                                    </li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/key-dates">Key
                                            Dates</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/key-dates-and-registration-fee">Registration</a>
                                    </li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/location">Conference
                                            Venue</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/immigration-visa">Immigration
                                            (VISA)</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/accommodation">Accommodation</a>
                                    </li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/local-attraction">Local
                                            Attraction</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/general-information">General
                                            Information</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/contact">Contact</a>
                                    </li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/conference-organizer-co-organizers-and-partners">Organizer
                                            and Co-organizer</a></li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/sponsors">Partners</a>
                                    </li>


                                    <li><i class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/downloads">Downloads</a>
                                    </li>


                                    <div id="accordion131" class="panel-group accordion">
                                        <div class="panel">
                                            <div class="panel-title">
                                                <a data-parent="#accordion131" data-toggle="collapse"
                                                    href="#accordion1131" class="" aria-expanded="true"> <span
                                                        class="open-sub"></span> Biography</a>
                                            </div>
                                            <div id="accordion1131" class="panel-collapse collapse" role="tablist"
                                                aria-expanded="true">
                                                <div class="panel-content">
                                                    <li><i
                                                            class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/prof-stephen-tee">Prof
                                                            Stephen Tee</a></li>
                                                    <li><i
                                                            class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/prof-padam-simkhada">Prof
                                                            Padam Simkhada</a></li>
                                                    <li><i
                                                            class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/prof-dr-sujan-babu-marahatta">Prof
                                                            Dr. Sujan Babu Marahatta</a></li>
                                                    <li><i
                                                            class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/kapil-dev-regmi">Kapil
                                                            Dev Regmi</a></li>
                                                    <li><i
                                                            class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/paul-bissell">Paul
                                                            Bissell</a></li>
                                                    <li><i
                                                            class="fa fa-angle-double-right mr-10 text-theme-colored"></i><a
                                                            href="https://conferencenepal.com/events/detail/6/apaccm2022/dr-francisco-rojas-aravena">Dr.
                                                            Francisco Rojas Aravena</a></li>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--  <section>
          <div class="divider parallax layer-overlay overlay-darkblue" data-stellar-background-ratio="0.5" data-bg-img="http://placehold.it/1920x1280">
            <div class="container pt-50 pb-50">
              <div class="section-title">
                <div class="row">
                  <div class="col-md-6 col-md-offset-3 text-center">
                    <h2 class="title text-white mb-0">Event Schedule</h2>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div data-bg-img="http://placehold.it/1920x1280">
            <div class="container pt-80 pb-60">
              <div class="section-content">
                <div class="row">
                  <div class="col-md-12">
                    <table class="table table-striped table-schedule">
                      <thead>
                        <tr>
                          <th>Time</th>
                          <th>Schedule</th>
                          <th>Venue</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><strong>Registration + Breakfast</strong></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><strong>Inauguration</strong></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><strong>Key Note</strong></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><a href="#">Fun with Animation API</a> by <a href="#">Jacob Doe</a></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><a href="#">Fun with Animation API</a> by <a href="#">Jacob Doe</a></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><a href="#">Fun with Animation API</a> by <a href="#">Jacob Doe</a></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><strong>Tea Break</strong></td>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><a href="#">Fun with Animation API</a> by <a href="#">Jacob Doe</a></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><a href="#">Fun with Animation API</a> by <a href="#">Jacob Doe</a></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><strong>Lunch Break</strong></td>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><a href="#">Fun with Animation API</a> by <a href="#">Jacob Doe</a></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><a href="#">Fun with Animation API</a> by <a href="#">Jacob Doe</a></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><a href="#">Fun with Animation API</a> by <a href="#">Jacob Doe</a></td>
                          <td>Room1</td>
                        </tr>
                        <tr>
                          <td>08:30am-10:00am</td>
                          <td><strong>Vote of Thanks</strong></td>
                          <td>Room1</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section> -->





    </div>
</div>

<?php echo $__env->make('layouts.frontend.inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\certificate Management System\certificate-management-system\resources\views/pages/frontend/event/detail.blade.php ENDPATH**/ ?>