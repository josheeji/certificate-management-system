
<?php $__env->startSection('title', 'Events Table'); ?>

<?php $__env->startSection('content'); ?>

    <!--  Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <form action=<?php echo e('/admin/events'); ?> method="POST" id="delete_form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Delete Event</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="event_delete_id" id="delete_event_id">
                        <h5>Are you sure, you want to delete this category ?</h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger">Yes, delete it</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- End Delete Modal -->


    <div class="col-lg-12">

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">EventS Table

                </h5>

                <!-- Default Table -->
                <?php if(session('message')): ?>
                    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                <?php endif; ?>
                <div class="card-body">
                    <a href="/admin/events/create" class="btn btn-primary btn-sm">
                        <h6>Add New Event</h6>
                    </a>
                    <hr>
                    <table id="myDataTable" class="table table-bordered">
                        <thead>
                            <tr>

                                <th scope="col">S.No.</th>
                                <th scope="col">Name</th>
                                <th scope="col">Organizer Name</th>
                                <th scope="col">Location</th>
                                <th scope="col">Event Type</th>
                                
                                <th scope="col">Start Date</th>
                                <th scope="col">End Date</th>

                                <th scope="col">Event start Time</th>

                                


                                <th class="text-center" width="170">Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=1 ?>

                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?> </td>
                                    <td><?php echo e($event->name); ?></td>

                                    <td><?php echo e($event->organizer_name); ?></td>
                                    <td><?php echo e($event->location); ?></td>
                                    <td><?php echo e($event->eventType->name); ?></td>
                                    

                                    <td><?php echo e($event->start_date); ?></td>
                                    <td><?php echo e($event->end_date); ?></td>
                                    
                                    <td> <?php echo e(\Carbon\Carbon::parse($event->event_time)->tz('Asia/Kathmandu')->format('h:i A')); ?>

                                    </td>

                                    


                                    <td class="text-center">
                                        <a title="Edit" href="/admin/events/<?php echo e($event->id); ?>/edit"
                                            class="btn btn-icon btn-circle btn-light"><i class="bi bi-pencil"></i></a>

                                        

                                        <button title="Delete" type="button"
                                            class="btn btn-icon btn-danger btn-circle delete deleteEventBtn"
                                            value="<?php echo e($event->id); ?>"><i class="bi bi-trash-fill"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function() {
            $('.deleteEventBtn').click(function(e) {
                e.preventDefault();

                var event_id = $(this).val();
                // $('#delete_event_id').val(event_id);

                $('#delete_form').attr('action', '/admin/events/' + event_id);
                $('#deleteModal').modal('show');


            });
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\certificate Management System\certificate-management-system\resources\views/pages/backend/event/index.blade.php ENDPATH**/ ?>