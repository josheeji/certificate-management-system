
<?php $__env->startSection('title', 'Participant Table'); ?>

<?php $__env->startSection('content'); ?>

    <!--  Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <form action=<?php echo e('/admin/participants'); ?> method="POST" id="delete_form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Delete Participation</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="participation_delete_id" id="delete_participation_id">
                        <h5>Are you sure, you want to delete this Participation ?</h5>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger">Yes, delete it</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- End Delete Modal -->


    <div class="col-lg-12">

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Participant Table

                </h5>

                <!-- Default Table -->
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php if(session('message')): ?>
                    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                <?php endif; ?>

                <div class="card-body">
                    <a href="/admin/participants/create" class="btn btn-primary btn-sm">
                        <h6>Add New Participants</h6>
                    </a>

                    <a href="/admin/participants/import" class="btn btn-primary btn-sm">
                        <h6>Import file</h6>
                    </a>
                    <a href="/admin/participants/export-participant-pdf" class="btn btn-success btn-sm">
                        <h6>Export Excel</h6>
                    </a>
                    <br><br>
                    <form action="">
                        <div class="row mb-3">
                            <div class="col-sm-4">
                                <select id="event_id" name="event_id" class="custom-select form-control">
                                    <option value="">Select Event*</option>
                                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option 
                                            value="<?php echo e($event->id); ?>"<?php echo e($event->id == request()->event_id ? 'selected' : ''); ?>>
                                            <?php echo e($event->name); ?>


                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php $__errorArgs = ['event_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class='text-danger'><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="col-md-3 mb-3">
                                <button type="submit" id="submit_form" class="btn btn-primary btn-fw">Search</button>

                            </div>
                        </div>
                    </form>
                    <hr>
                    <table id="myDataTable" class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col" width="0.5%">S.No.</th>
                                <th scope="col">Name</th>
                                <th scope="col">Affilated Isntitute</th>
                                <th scope="col">Post</th>
                                <th scope="col">Event Name</th>
                                <th scope="col">Participant Type</th>
                                <th class="text-center" width="170">Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=1 ?>

                            <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($participant->name); ?></td>
                                    <td><?php echo e($participant->affilated_institute); ?></td>
                                    <td><?php echo e($participant->post); ?></td>


                                    <td><?php echo e($participant->event->name); ?></td>
                                    <td><?php echo e($participant->participantType->name); ?></td>



                                    <td class="text-center">
                                        <a title="Download PDF"
                                            href="/admin/participants/<?php echo e($participant->id); ?>/download-pdf"
                                            class="btn btn-primary" class="bi bi-arrow-down-circle-fill"><i
                                                class="bi bi-arrow-down-circle-fill"></i></a>

                                        <a title="Edit" href="/admin/participants/<?php echo e($participant->id); ?>/edit"
                                            class="btn btn-icon btn-circle btn-light"><i class="bi bi-pencil"></i></a>

                                        <button title="Delete" type="button"
                                            class="btn btn-icon btn-danger btn-circle delete deleteParticipantsBtn"
                                            value="<?php echo e($participant->id); ?>"><i class="bi bi-trash-fill"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function() {
            $('.deleteParticipantsBtn').click(function(e) {
                e.preventDefault();
                
                // initializing the value
                var participant_id = $(this).val();
                $('#delete_participation_id').val(participant_id);

                $('#delete_form').attr('action', '/admin/participants/' + participant_id);
                $('#deleteModal').modal('show');


            });
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\certificate Management System\certificate-management-system\resources\views/pages/backend/participant/index.blade.php ENDPATH**/ ?>