

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <div class="main-content">
            <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5"
                data-bg-img="https://conferencenepal.com/images/bg11.jpg">
                <div class="container pt-2 pb-0">
                    <!-- Section Content -->
                    <div class="section-content pt-2">
                        <div class="row">
                            <div class="col-md-12">
                                <h2 class="title text-white">Download Certificate</h2>
                            </div>
                            <div class="col-md-12" style="display:none">
                                <ol class="breadcrumb text-center mt-10 white">
                                    <li><a href="https://conferencenepal.com/home">Home</a></li>
                                    <li class="active">5th National Conference of SIMON Certificate Download</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Section: Past Events -->

            

            <div class="container pb-50 pt-500">
                <ol>
                    <h3><?php echo e($events->name); ?></h3>
                </ol>

                <div class="section-content">
                    <div class="row">
                        <div class="col-sm-12">
                            <table id="myDataTable" role="grid" aria-describedby="table_info"
                                class="table table-striped table-hover table-hover table-schedule dataTable no-footer">
                                <thead>
                                    <tr>
                                        <th scope="col">S.No.</th>
                                        <th scope="col">Full Name</th>
                                        <th scope="col">Event Name</th>
                                        <th scope="col">Participant Type</th>
                                        <th scope="col">Download</th>

                                    </tr>
                                </thead>

                                <tbody>

                                    <?php $i = 1 ?>

                                    <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($participant->name); ?></td>
                                            <td><?php echo e($participant->event->name); ?></td>
                                            <td><?php echo e($participant->participantType->name); ?></td>

                                            <td class="text-center">
                                                <a title="Download PDF"
                                                    href="/admin/participants/<?php echo e($participant->id); ?>/download-pdf"
                                                    class="btn btn-primary" class="bi bi-arrow-down-circle-fill"><i
                                                        class="bi bi-arrow-down-circle-fill"></i></a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                               
                            </table>
                            <a href="<?php echo e(url('/home')); ?>"> <button type="button" class="btn btn-success">Back
                            </button> </a>
                        </div>
                    </div>
                </div>

            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.inc.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\certificate Management System\certificate-management-system\resources\views/pages/frontend/event/index.blade.php ENDPATH**/ ?>