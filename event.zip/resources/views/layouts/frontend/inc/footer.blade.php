 <!-- Footer -->
    <footer id="footer" class="footer" >

        <div class="container-fluid p-20" data-bg-color="#181818">
            <div class="row text-center">
                <div class="col-md-12">
                    <p class="font-11 m-0" data-text-color="#555">Copyright &copy;2023 <a class="font-11"
                            href="#">Conference Nepal</a>. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>