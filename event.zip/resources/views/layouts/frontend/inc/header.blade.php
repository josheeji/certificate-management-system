<header class="header">
    <div
        class="header-nav navbar-fixed-top navbar-dark navbar-transparent navbar-sticky-animated animated-active">
        <div class="header-nav-wrapper">
            <div class="container">
                <nav id="menuzord-right" class="menuzord green">
                    <a class="menuzord-brand pull-left flip" href="https://conferencenepal.com/home"><img
                            src="https://conferencenepal.com/images/logo-wide.png" alt=""></a>
                    <ul class="menuzord-menu">
                        <!-- <li ><a href="https://conferencenepal.com/home">Home</a></li>  -->

                        <!--    <li ><a href="https://conferencenepal.com/pages/page/about">About Us</a></li> -->

                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>